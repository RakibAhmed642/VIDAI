export interface Analysis {
  timestamp: number;
  image: string;
  description: string;
}

export interface Settings {
  captureInterval: number;
  enableAudio: boolean;
  enableStorage: boolean;
}

export interface AudioTranscript {
  timestamp: number;
  text: string;
  response: string;
}