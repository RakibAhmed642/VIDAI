import { GoogleGenerativeAI } from '@google/generative-ai';

const API_KEY = 'AIzaSyDC1oe0mr2ZrbrR5xFvj8hFQE6XK_Lcchs';
const genAI = new GoogleGenerativeAI(API_KEY);

export async function analyzeImage(imageBase64: string): Promise<string> {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash-001' });
    const prompt = 'Describe what you see in this image in a brief, concise way (1-2 sentences) also dont say this image show.just describe what you see in image.';
    
    const result = await model.generateContent([
      prompt,
      {
        inlineData: {
          mimeType: 'image/jpeg',
          data: imageBase64.split(',')[1]
        }
      }
    ]);

    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error analyzing image:', error);
    throw error;
  }
}

export async function analyzeAudio(transcript: string, imageContext?: string): Promise<string> {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    const prompt = imageContext 
      ? `Given the current scene context: "${imageContext}", please provide a relevant response to this audio input: "${transcript}"`
      : `Please provide a brief and helpful response to this audio input: "${transcript}"`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error analyzing audio:', error);
    throw error;
  }
}

export async function combinedAnalysis(imageBase64: string, transcript: string): Promise<string> {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    const imageDescription = await analyzeImage(imageBase64);
    
    const prompt = `
      Context: I'm looking at a scene where "${imageDescription}"
      
      Given this visual context, please provide a natural and contextual response to the following input: "${transcript}"
      
      Combine both the visual context and the voice input to provide a coherent and relevant response.
    `;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error in combined analysis:', error);
    throw error;
  }
}