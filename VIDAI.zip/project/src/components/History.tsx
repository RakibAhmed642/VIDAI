import React from 'react';
import { Analysis } from '../types';
import { History as HistoryIcon, Trash2 } from 'lucide-react';

interface HistoryProps {
  analyses: Analysis[];
  onDelete: (timestamp: number) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function History({ analyses, onDelete, isOpen, onClose }: HistoryProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 w-[32rem] max-h-[80vh] overflow-hidden flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <HistoryIcon className="w-5 h-5" />
            Analysis History
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            ✕
          </button>
        </div>

        <div className="overflow-y-auto flex-1">
          {analyses.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No analyses saved yet</p>
          ) : (
            <div className="space-y-4">
              {analyses.map((analysis) => (
                <div key={analysis.timestamp} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-sm text-gray-500">
                      {new Date(analysis.timestamp).toLocaleString()}
                    </span>
                    <button
                      onClick={() => onDelete(analysis.timestamp)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <img
                    src={analysis.image}
                    alt="Captured"
                    className="w-full h-32 object-cover rounded-md mb-2"
                  />
                  <p className="text-sm">{analysis.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        <button
          onClick={onClose}
          className="w-full mt-4 bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600"
        >
          Close
        </button>
      </div>
    </div>
  );
}