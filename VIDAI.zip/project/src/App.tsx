import React, { useState, useRef, useCallback, useEffect } from 'react';
import Webcam from 'react-webcam';
import { Camera, Settings as SettingsIcon, History as HistoryIcon, PlayCircle, StopCircle, FlipHorizontal, Mic, MicOff } from 'lucide-react';
import { Settings } from './components/Settings';
import { History } from './components/History';
import { analyzeImage, analyzeAudio, combinedAnalysis } from './utils/gemini';
import { Analysis, Settings as SettingsType, AudioTranscript } from './types';

function App() {
  const [isRunning, setIsRunning] = useState(false);
  const [currentDescription, setCurrentDescription] = useState('');
  const [error, setError] = useState('');
  const [settings, setSettings] = useState<SettingsType>({
    captureInterval: 5,
    enableAudio: false,
    enableStorage: true
  });
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isRecording, setIsRecording] = useState(false);
  const [audioTranscripts, setAudioTranscripts] = useState<AudioTranscript[]>([]);
  const [lastImageSrc, setLastImageSrc] = useState<string | null>(null);

  const webcamRef = useRef<Webcam>(null);
  const captureIntervalRef = useRef<number>();
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance>();
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    speechSynthesisRef.current = new SpeechSynthesisUtterance();
    
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = false;

      recognitionRef.current.onresult = async (event) => {
        const transcript = event.results[event.results.length - 1][0].transcript;
        let response;
        
        if (isRunning && lastImageSrc) {
          // If both camera and voice are active, use combined analysis
          response = await combinedAnalysis(lastImageSrc, transcript);
        } else {
          // Otherwise, just analyze the audio
          response = await analyzeAudio(transcript, currentDescription);
        }
        
        const newTranscript: AudioTranscript = {
          timestamp: Date.now(),
          text: transcript,
          response
        };
        
        setAudioTranscripts(prev => [newTranscript, ...prev]);
        
        if (settings.enableAudio && speechSynthesisRef.current) {
          speechSynthesis.cancel();
          speechSynthesisRef.current.text = response;
          speechSynthesis.speak(speechSynthesisRef.current);
        }
      };
    }
  }, [settings.enableAudio, isRunning, currentDescription, lastImageSrc]);

  const captureAndAnalyze = useCallback(async () => {
    if (!webcamRef.current || !isRunning) return;

    try {
      setError('');
      const imageSrc = webcamRef.current.getScreenshot();
      if (!imageSrc) return;

      setLastImageSrc(imageSrc);
      const description = await analyzeImage(imageSrc);
      setCurrentDescription(description);

      if (settings.enableAudio && speechSynthesisRef.current && !isRecording) {
        speechSynthesis.cancel();
        speechSynthesisRef.current.text = description;
        speechSynthesis.speak(speechSynthesisRef.current);
      }

      if (settings.enableStorage) {
        const analysis: Analysis = {
          timestamp: Date.now(),
          image: imageSrc,
          description
        };
        setAnalyses(prev => [analysis, ...prev]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to analyze image');
    }
  }, [settings, isRunning, isRecording]);

  useEffect(() => {
    if (isRunning) {
      captureIntervalRef.current = window.setInterval(
        captureAndAnalyze,
        settings.captureInterval * 1000
      );
    } else {
      if (captureIntervalRef.current) {
        clearInterval(captureIntervalRef.current);
      }
    }

    return () => {
      if (captureIntervalRef.current) {
        clearInterval(captureIntervalRef.current);
      }
    };
  }, [settings.captureInterval, captureAndAnalyze, isRunning]);

  const toggleCapture = () => {
    setIsRunning(!isRunning);
    if (!isRunning) {
      setCurrentDescription('');
    }
  };

  const toggleCamera = () => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  };

  const toggleAudioRecording = () => {
    if (!recognitionRef.current) return;

    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
    }
    setIsRecording(!isRecording);
  };

  const deleteAnalysis = (timestamp: number) => {
    setAnalyses(prev => prev.filter(a => a.timestamp !== timestamp));
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-4xl mx-auto p-2 sm:p-4">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="p-3 sm:p-4 border-b flex justify-between items-center">
            <h1 className="text-lg sm:text-xl font-semibold flex items-center gap-2">
              <Camera className="w-5 h-5 sm:w-6 sm:h-6" />
              Real-time Camera Analysis
            </h1>
            <div className="flex gap-2">
              <button
                onClick={() => setShowHistory(true)}
                className="p-1.5 sm:p-2 hover:bg-gray-100 rounded-full"
                aria-label="History"
              >
                <HistoryIcon className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={() => setShowSettings(true)}
                className="p-1.5 sm:p-2 hover:bg-gray-100 rounded-full"
                aria-label="Settings"
              >
                <SettingsIcon className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            </div>
          </div>

          <div className="p-3 sm:p-4">
            <div className="relative">
              <Webcam
                ref={webcamRef}
                audio={false}
                screenshotFormat="image/jpeg"
                className="w-full rounded-lg"
                videoConstraints={{
                  facingMode,
                  width: { ideal: 1280 },
                  height: { ideal: 720 }
                }}
              />
              <div className="absolute bottom-4 right-4 flex gap-2">
                <button
                  onClick={toggleCamera}
                  className="p-2 rounded-full bg-gray-800 bg-opacity-75 text-white hover:bg-opacity-90 transition-colors"
                  aria-label="Switch Camera"
                >
                  <FlipHorizontal className="w-6 h-6" />
                </button>
                <button
                  onClick={toggleAudioRecording}
                  className={`p-2 rounded-full ${
                    isRecording ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-800 bg-opacity-75 hover:bg-opacity-90'
                  } text-white transition-colors`}
                  aria-label={isRecording ? 'Stop Recording' : 'Start Recording'}
                >
                  {isRecording ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </button>
                <button
                  onClick={toggleCapture}
                  className={`p-2 rounded-full ${
                    isRunning ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'
                  } text-white transition-colors`}
                  aria-label={isRunning ? 'Stop Capture' : 'Start Capture'}
                >
                  {isRunning ? <StopCircle className="w-6 h-6" /> : <PlayCircle className="w-6 h-6" />}
                </button>
              </div>
            </div>

            <div className="mt-3 sm:mt-4">
              {error ? (
                <div className="bg-red-50 text-red-500 p-3 sm:p-4 rounded-lg text-sm sm:text-base">
                  {error}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-gray-50 p-3 sm:p-4 rounded-lg">
                    <h2 className="font-semibold mb-2 text-sm sm:text-base">Camera Analysis:</h2>
                    <p className="text-sm sm:text-base">
                      {isRunning 
                        ? (currentDescription || 'Waiting for first analysis...')
                        : 'Click the play button to start analysis'}
                    </p>
                  </div>
                  {audioTranscripts.length > 0 && (
                    <div className="bg-gray-50 p-3 sm:p-4 rounded-lg">
                      <h2 className="font-semibold mb-2 text-sm sm:text-base">Latest Voice Interaction:</h2>
                      <div className="space-y-2">
                        <p className="text-sm text-gray-600">You said: {audioTranscripts[0].text}</p>
                        <p className="text-sm">AI Response: {audioTranscripts[0].response}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <Settings
        settings={settings}
        onSettingsChange={setSettings}
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
      />

      <History
        analyses={analyses}
        onDelete={deleteAnalysis}
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
      />
    </div>
  );
}

export default App;